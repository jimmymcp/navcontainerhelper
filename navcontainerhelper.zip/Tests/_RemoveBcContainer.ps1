﻿Remove-BCContainer -containerName $bcContainerName
